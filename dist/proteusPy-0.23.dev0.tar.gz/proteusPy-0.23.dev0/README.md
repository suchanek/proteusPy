*proteusPy* is a python package specializing on the modeling and analysis of proteins of known structure with an emphasis on Disulfide Bonds. This package reprises my molecular modeling and analysis program [Proteus](https://doi.org/10.1021/bi00368a023), and relies heavily on the [Turtle3D](https://suchanek.github.io/proteusPy/proteusPy/turtle3D.html) class. The turtle implements the functions ``Move``, ``Roll``, ``Yaw``, ``Pitch`` and ``Turn`` for movement in a three-dimensional space. The [Disulfide](https://suchanek.github.io/proteusPy/proteusPy/Disulfide.html) class implements the protein structure stabilizing element known as a Disulfide Bond. This class and its underlying methods are being used to perform a structural analysis of over 292,000 disulfide-bond containing proteins in the RCSB protein data bank.

*NB:* This distribution is actively being developed and will be difficult to implement locally unless the BioPython patch is applied. Also, if you're running on an M-series Mac then it's important to install Biopython first, since the generic release won't build on the M1. 1/26/23 -egs

Eric G. Suchanek, PhD. [suchanek@mac.com](mailto:suchanek@mac.com)

